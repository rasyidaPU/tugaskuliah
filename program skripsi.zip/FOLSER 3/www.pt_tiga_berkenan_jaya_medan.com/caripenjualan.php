<?php require_once('Connections/skripsi.php'); ?>
<?php
$colname_caripenjualan = "-1";
if (isset($_GET['nama_perusahaan'])) {
  $colname_caripenjualan = (get_magic_quotes_gpc()) ? $_GET['nama_perusahaan'] : addslashes($_GET['nama_perusahaan']);
}
mysql_select_db($database_skripsi, $skripsi);
$query_caripenjualan = sprintf("SELECT * FROM tbl_penjualan WHERE nama_perusahaan = '%s'", $colname_caripenjualan);
$caripenjualan = mysql_query($query_caripenjualan, $skripsi) or die(mysql_error());
$row_caripenjualan = mysql_fetch_assoc($caripenjualan);
$totalRows_caripenjualan = mysql_num_rows($caripenjualan);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
#Layer1 {position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -4px;
	top: -3px;
}
#Layer16 {position:absolute;
	width:123px;
	height:83px;
	z-index:16;
	left: 307px;
	top: 148px;
}
.style1 {font-size: 24px;
	font-style: italic;
	font-weight: bold;
}
.style4 {color: #FFFFFF}
#Layer6 {position:absolute;
	width:604px;
	height:33px;
	z-index:2;
	left: 321px;
	top: 127px;
}
.style3 {font-size: 18px}
#Layer7 {position:absolute;
	width:407px;
	height:11px;
	z-index:3;
	left: 419px;
	top: 157px;
}
#Layer8 {position:absolute;
	width:366px;
	height:28px;
	z-index:4;
	left: 432px;
	top: 174px;
}
#Layer9 {position:absolute;
	width:258px;
	height:22px;
	z-index:5;
	left: 482px;
	top: 211px;
}
.style5 {font-size: 24px;
	color: #FFFFFF;
	font-weight: bold;
}
#Layer11 {position:absolute;
	width:460px;
	height:27px;
	z-index:13;
	left: 350px;
	top: 235px;
}
#Layer13 {position:absolute;
	width:200px;
	height:115px;
	z-index:14;
	top: 263px;
	left: 124px;
}
body {
	background-color: #0099CC;
}
#Layer2 {
	position:absolute;
	width:463px;
	height:115px;
	z-index:17;
	left: 343px;
	top: 338px;
}
.style6 {
	font-size: 24px;
	color: #FFFFFF;
}
#Layer3 {
	position:absolute;
	width:86px;
	height:25px;
	z-index:18;
	left: 350px;
	top: 296px;
}
.style7 {font-size: 24px}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #FFFFFF;
}
-->
</style>
</head>

<body>
<div id="Layer1"><img src="logo.jpg" width="1372" height="238" /></div>
<div id="Layer16"><img src="logo pt 2.png" width="132" height="83" /></div>
<div class="style1" id="Layer6">
  <div align="center">
    <p class="style4">General Supplier &amp; Contractor</p>
  </div>
</div>
<div class="style3" id="Layer7">
  <p align="left" class="style4"><strong>Alat Besar Laboratorium Farmasi dan Kedokteran </strong></p>
  <p align="center">&nbsp;</p>
</div>
<div id="Layer8">
  <p align="left" class="style4"><strong>Jl. Bunga Ncole LK.II No. 11 Kel. Kemenangan Tani</strong></p>
</div>
<div class="style4" id="Layer9"><strong>Telp (061)6628933 Faks.(061)6622768</strong></div>
<div id="Layer13"><img src="latar produk.jpg" width="1080" height="720" /></div>
<div class="style5" id="Layer11">
  <marquee>
    Form Cari PT. Tiga Berkenan Jaya Medan
  </marquee>
</div>
<div id="Layer2">
  <form id="form1" name="form1" method="get" action="">
    <label><span class="style6">Cari data</span>
      <input name="nama_perusahaan" type="text" id="nama_perusahaan" />
    </label>
    <label>
    <input type="submit" name="Submit" value="cari" />
    </label>
<p>&nbsp;</p>
  
<?php if ($totalRows_caripenjualan > 0) { // Show if recordset not empty ?>
  <table border="1" bordercolor="#FF9900">
      <tr>
        <td bgcolor="#FFFFFF">kode_penjualan</td>
          <td bgcolor="#FFFFFF">kode_pemesanan</td>
          <td bgcolor="#FFFFFF">nama_perusahaan</td>
          <td bgcolor="#FFFFFF">alamat</td>
          <td bgcolor="#FFFFFF">nama_produk</td>
          <td bgcolor="#FFFFFF">jumlah_produk</td>
          <td bgcolor="#FFFFFF">harga</td>
        </tr>
      <?php do { ?>
          <tr>
            <td bgcolor="#33FF99"><?php echo $row_caripenjualan['kode_penjualan']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['kode_pemesanan']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['nama_perusahaan']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['alamat']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['nama_produk']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['jumlah_produk']; ?></td>
            <td bgcolor="#33FFFF"><?php echo $row_caripenjualan['harga']; ?></td>
          </tr>
          <?php } while ($row_caripenjualan = mysql_fetch_assoc($caripenjualan)); ?>
      </table>
  <?php } // Show if recordset not empty ?></form>
</div>
<div class="style7" id="Layer3"><a href="penjualan.php">Kembali</a></div>
</body>
</html>
<?php
mysql_free_result($caripenjualan);
?>
