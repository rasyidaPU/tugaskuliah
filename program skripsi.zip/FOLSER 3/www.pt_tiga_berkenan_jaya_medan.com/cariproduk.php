<?php require_once('Connections/skripsi.php'); ?>
<?php
$colname_Recordset1 = "-1";
if (isset($_GET['nama_produk'])) {
  $colname_Recordset1 = (get_magic_quotes_gpc()) ? $_GET['nama_produk'] : addslashes($_GET['nama_produk']);
}
mysql_select_db($database_skripsi, $skripsi);
$query_Recordset1 = sprintf("SELECT * FROM table_produk WHERE nama_produk = '%s'", $colname_Recordset1);
$Recordset1 = mysql_query($query_Recordset1, $skripsi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 24px;
	font-style: italic;
	font-weight: bold;
}
.style3 {font-size: 18px}
.style4 {color: #FFFFFF}
.style5 {font-size: 24px;
	color: #FFFFFF;
	font-weight: bold;
}
.style6 {color: #FF0000}
#Layer1 {position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -4px;
	top: -3px;
}
#Layer11 {position:absolute;
	width:476px;
	height:25px;
	z-index:13;
	left: 350px;
	top: 234px;
}
#Layer13 {position:absolute;
	width:200px;
	height:115px;
	z-index:14;
	top: 262px;
	left: 124px;
}
#Layer16 {position:absolute;
	width:123px;
	height:83px;
	z-index:16;
	left: 307px;
	top: 148px;
}
#Layer2 {	position:absolute;
	width:485px;
	height:115px;
	z-index:17;
	left: 284px;
	top: 299px;
}
#Layer6 {position:absolute;
	width:604px;
	height:33px;
	z-index:2;
	left: 321px;
	top: 127px;
}
#Layer7 {position:absolute;
	width:407px;
	height:11px;
	z-index:3;
	left: 419px;
	top: 157px;
}
#Layer8 {position:absolute;
	width:366px;
	height:28px;
	z-index:4;
	left: 432px;
	top: 174px;
}
#Layer9 {position:absolute;
	width:258px;
	height:22px;
	z-index:5;
	left: 482px;
	top: 211px;
}
body {
	background-color: #33FF66;
}
#Layer3 {
	position:absolute;
	width:403px;
	height:115px;
	z-index:17;
	left: 365px;
	top: 337px;
}
#Layer4 {
	position:absolute;
	width:87px;
	height:29px;
	z-index:18;
	left: 366px;
	top: 276px;
}
.style7 {font-size: 24px}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #FFFFFF;
}
-->
</style>
</head>

<body>
<div id="Layer1"><img src="logo.jpg" width="1372" height="238" /></div>
<div class="style1" id="Layer6">
  <div align="center">
    <p class="style4">General Supplier &amp; Contractor</p>
  </div>
</div>
<div class="style3" id="Layer7">
  <p align="left" class="style4"><strong>Alat Besar Laboratorium Farmasi dan Kedokteran </strong></p>
  <p align="center">&nbsp;</p>
</div>
<div id="Layer8">
  <p align="left" class="style4"><strong>Jl. Bunga Ncole LK.II No. 11 Kel. Kemenangan Tani</strong></p>
</div>
<div class="style4" id="Layer9"><strong>Telp (061)6628933 Faks.(061)6622768</strong></div>
<div id="Layer16"><img src="logo pt 2.png" width="132" height="83" /></div>
<div class="style5" id="Layer11"> <span class="style6">
  <marquee>
    Form Cari PT. Tiga Berkenan Jaya Medan
  </marquee>
</span></div>
<div id="Layer13"><img src="latar produk.jpg" width="1080" height="720" /></div>
<div id="Layer3">
  <form id="form1" name="form1" method="get" action="">
    <label><span class="style4">Cari Nama Produk</span>
    <input name="nama_produk" type="text" id="nama_produk" />
</label>
    <label>
    <input type="submit" name="Submit" value="cari" />
    </label>
    <p>&nbsp;</p>
  
    <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
      <table border="1" bordercolor="#00FF00" bgcolor="#00CCFF">
        <tr>
          <td bgcolor="#FFFFFF">kode_produk</td>
          <td bgcolor="#FFFFFF">nama_produk</td>
          <td bgcolor="#FFFFFF">harga</td>
          <td bgcolor="#FFFFFF">jumlah_produk</td>
        </tr>
        <?php do { ?>
          <tr>
            <td><?php echo $row_Recordset1['kode_produk']; ?></td>
            <td><?php echo $row_Recordset1['nama_produk']; ?></td>
            <td><?php echo $row_Recordset1['harga']; ?></td>
            <td><?php echo $row_Recordset1['jumlah_produk']; ?></td>
          </tr>
          <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
      </table>
      <?php } // Show if recordset not empty ?></form>
</div>
<div class="style7" id="Layer4"><a href="Produk.php">Kembali</a></div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
