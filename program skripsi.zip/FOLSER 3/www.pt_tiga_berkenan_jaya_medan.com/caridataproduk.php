<?php require_once('Connections/skripsi.php'); ?>
<?php
$colname_caridata = "-1";
if (isset($_GET['nama_produk'])) {
  $colname_caridata = (get_magic_quotes_gpc()) ? $_GET['nama_produk'] : addslashes($_GET['nama_produk']);
}
mysql_select_db($database_skripsi, $skripsi);
$query_caridata = sprintf("SELECT * FROM table_produk WHERE nama_produk = '%s'", $colname_caridata);
$caridata = mysql_query($query_caridata, $skripsi) or die(mysql_error());
$row_caridata = mysql_fetch_assoc($caridata);
$totalRows_caridata = mysql_num_rows($caridata);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:742px;
	height:115px;
	z-index:1;
	left: 188px;
	top: 369px;
}
body {
	background-color: #66CC66;
}
-->
</style>
</head>

<body>
<div id="Layer1">
  <form id="form1" name="form1" method="get" action="">
    <label>Cari data
      <input name="nama_produk" type="text" id="nama_produk" />
    </label>
    <label>
    <input type="submit" name="Submit" value="cari" />
    </label>
    <p>&nbsp;</p>
    <?php if ($totalRows_caridata > 0) { // Show if recordset not empty ?>
    <table border="1">
      <tr>
        <td>kode_produk</td>
        <td>nama_produk</td>
        <td>harga</td>
        <td>jumlah_produk</td>
      </tr>
      <?php do { ?>
      <tr>
        <td><?php echo $row_caridata['kode_produk']; ?></td>
        <td><?php echo $row_caridata['nama_produk']; ?></td>
        <td><?php echo $row_caridata['harga']; ?></td>
        <td><?php echo $row_caridata['jumlah_produk']; ?></td>
      </tr>
      <?php } while ($row_caridata = mysql_fetch_assoc($caridata)); ?>
    </table>
    <?php } // Show if recordset not empty ?>
    <p>&nbsp;</p>
  </form>
</div>
<div id="layer"><img src="logo.jpg" width="1372" height="238" /></div>
</body>
</html>
<?php
mysql_free_result($caridata);
?>
