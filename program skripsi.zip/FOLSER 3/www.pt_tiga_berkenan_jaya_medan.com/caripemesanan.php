<?php require_once('Connections/skripsi.php'); ?>
<?php
$colname_caripemesanan = "-1";
if (isset($_GET['nama_perusahaan'])) {
  $colname_caripemesanan = (get_magic_quotes_gpc()) ? $_GET['nama_perusahaan'] : addslashes($_GET['nama_perusahaan']);
}
mysql_select_db($database_skripsi, $skripsi);
$query_caripemesanan = sprintf("SELECT * FROM tbl_pemesanan WHERE nama_perusahaan = '%s'", $colname_caripemesanan);
$caripemesanan = mysql_query($query_caripemesanan, $skripsi) or die(mysql_error());
$row_caripemesanan = mysql_fetch_assoc($caripemesanan);
$totalRows_caripemesanan = mysql_num_rows($caripemesanan);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
#Layer1 {position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -4px;
	top: -3px;
}
.style1 {font-size: 24px;
	font-style: italic;
	font-weight: bold;
}
.style4 {color: #FFFFFF}
#Layer6 {position:absolute;
	width:604px;
	height:33px;
	z-index:2;
	left: 321px;
	top: 127px;
}
.style3 {font-size: 18px}
#Layer7 {position:absolute;
	width:407px;
	height:11px;
	z-index:3;
	left: 419px;
	top: 157px;
}
#Layer8 {position:absolute;
	width:366px;
	height:28px;
	z-index:4;
	left: 432px;
	top: 174px;
}
#Layer9 {position:absolute;
	width:258px;
	height:22px;
	z-index:5;
	left: 482px;
	top: 211px;
}
#Layer16 {	position:absolute;
	width:123px;
	height:83px;
	z-index:16;
	left: 307px;
	top: 148px;
}
.style5 {font-size: 24px;
	color: #FFFFFF;
	font-weight: bold;
}
#Layer11 {position:absolute;
	width:476px;
	height:25px;
	z-index:13;
	left: 350px;
	top: 234px;
}
body {
	background-color: #00CCCC;
}
#Layer13 {position:absolute;
	width:200px;
	height:115px;
	z-index:14;
	top: 262px;
	left: 124px;
}
#Layer2 {
	position:absolute;
	width:485px;
	height:115px;
	z-index:17;
	left: 284px;
	top: 299px;
}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #FFFFFF;
}
.style6 {color: #FF0000}
-->
</style>
</head>

<body>
<div id="Layer1"><img src="logo.jpg" width="1372" height="238" /></div>
<div class="style1" id="Layer6">
  <div align="center">
    <p class="style4">General Supplier &amp; Contractor</p>
  </div>
</div>
<div class="style3" id="Layer7">
  <p align="left" class="style4"><strong>Alat Besar Laboratorium Farmasi dan Kedokteran </strong></p>
  <p align="center">&nbsp;</p>
</div>
<div id="Layer8">
  <p align="left" class="style4"><strong>Jl. Bunga Ncole LK.II No. 11 Kel. Kemenangan Tani</strong></p>
</div>
<div class="style4" id="Layer9"><strong>Telp (061)6628933 Faks.(061)6622768</strong></div>
<div id="Layer16"><img src="logo pt 2.png" width="132" height="83" /></div>
<div class="style5" id="Layer11">
  <span class="style6">
  <marquee>
    Form Cari PT. Tiga Berkenan Jaya Medan
  </marquee>
</span></div>
<div id="Layer13"><img src="latar produk.jpg" width="1080" height="720" /></div>
<div id="Layer2">
  <form id="form1" name="form1" method="get" action="">
    <label><span class="style4">Cari Nama Perusahaan</span>
    <input name="nama_perusahaan" type="text" id="nama_perusahaan" />
</label>
    <label>
    <input type="submit" name="Submit" value="cari" />
    </label>
    <a href="pemesanan.php">Kembali</a>    
 <p>&nbsp;</p>
  
    <?php if ($totalRows_caripemesanan > 0) { // Show if recordset not empty ?>
      <table border="1">
        <tr>
          <td width="214" bgcolor="#330000"><span class="style4">kode_pemesanan</span></td>
          <td width="216" bgcolor="#330000"><span class="style4">nama_perusahaan</span></td>
          <td width="147" bgcolor="#330000"><span class="style4">alamat</span></td>
          <td width="150" bgcolor="#330000"><span class="style4">tanggal</span></td>
          <td width="192" bgcolor="#330000"><span class="style4">nomor_telpon</span></td>
          <td width="192" bgcolor="#330000"><span class="style4">nama_produk</span></td>
          <td width="141" bgcolor="#330000"><span class="style4">harga</span></td>
          <td width="199" bgcolor="#330000"><span class="style4">jumlah_produk</span></td>
          <td width="158" bgcolor="#330000"><span class="style4">total</span></td>
        </tr>
        <?php do { ?>
          <tr>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['kode_pemesanan']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['nama_perusahaan']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['alamat']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['tanggal']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['nomor_telpon']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['nama_produk']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['harga']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['jumlah_produk']; ?></div></td>
            <td bgcolor="#FFFFFF"><div align="center"><?php echo $row_caripemesanan['total']; ?></div></td>
          </tr>
          <?php } while ($row_caripemesanan = mysql_fetch_assoc($caripemesanan)); ?>
              </table>
      <?php } // Show if recordset not empty ?></form>
</div>
</body>
</html>
<?php
mysql_free_result($caripemesanan);
?>
