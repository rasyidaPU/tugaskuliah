/*
 Highcharts JS v6.1.0 (2018-04-13)

 (c) 2009-2017 Torstein Honsi

 License: www.highcharts.com/license
*/
(function(a){"object"===typeof module&&module.exports?module.exports=a:a(Highcharts)})(function(a){});
